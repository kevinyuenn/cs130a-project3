#include "avltree.h"
#include <iostream>

using namespace std;

int main(){
    AVLtree test(1);
    test.insert(5,0);
    test.insert(1,0);
    test.insert(2,0);
    // test.insert(7,0);
    // test.insert(8,0);
    // test.insert(9,0);
    test.printInOrder();
    test.printPreOrder();
}