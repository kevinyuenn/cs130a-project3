#include "avltree.h"
#include <tuple>
#include <iostream>
#include <math.h>

using namespace std;


AVLtree::AVLtree() 
{
    k = -1;
}

AVLtree::~AVLtree() 
{
    clear(root);
}

void AVLtree::clear(AVLtree::Node *n) 
{
    if (n) {
	clear(n->left);
	clear(n->right);
	delete n;
    }
}

void AVLtree::insert(int integer, int decimal) 
{   
    if(!root){
        root = new Node(integer, decimal);
        return;
    }
    return insert(root, integer, decimal);
}

void AVLtree::insert(Node *n, int integer, int decimal) 
{
    if(integer == get<0>(n->value) && decimal == get<1>(n->value))
        return;

    if(integer < get<0>(n->value)){
        if(n->left)
            return insert(n->left, integer, decimal);
        else{
            Node *p = new Node(integer, decimal);
            n->left = p;
            p->parent = n;
            findRotation(p);
            return;
        }
    }
    else if(integer > get<0>(n->value)){
        if(n->right)
            return insert(n->right, integer, decimal);
        else {
            Node *p = new Node(integer, decimal);
            n->right = p;
            p->parent = n;
            findRotation(p);
            return;
        }
    }
    else if(integer == get<0>(n->value)){
        if(decimal < get<1>(n->value)){
            if(n->left)
                return insert(n->left, integer, decimal);
            else{
                Node *p = new Node(integer, decimal);
                n->left = p;
                p->parent = n;
                findRotation(p);
                return;
            }
        }
        else if(decimal > get<1>(n->value)){
            if(n->right)
                return insert(n->right, integer, decimal);
            else {
                Node *p = new Node(integer, decimal);
                n->right = p;
                p->parent = n;
                findRotation(p);
                return;
            }
        }
    }
}

void AVLtree::findRotation(Node *n) 
{
    if(!n) return;
    if(fabs(getLHeight(n) - getRHeight(n)) > k){ //if RH and LH differ by >k
        Node *p = deepestNode(n);
        rotate(p);
        findRotation(p->parent);
    }
    // findRotation(n->parent);
}

void AVLtree::remove(int integer, int decimal) 
{
    
}

bool AVLtree::search(int integer, int decimal) 
{
    if (getNodeFor(integer, decimal, root)) return true;
    return false;
}

tuple<int,int> AVLtree::approxSearch(int integer, int decimal) 
{
    
}

void AVLtree::printInOrder() 
{
    printInOrder(root);
}

void AVLtree::printPreOrder() 
{
    printPreOrder(root);
}

void AVLtree::printInOrder(AVLtree::Node *n) 
{
    if (!n) return;
        printInOrder(n->left);
        cout<<get<0>(n->value)<<"."<<get<1>(n->value)<<" ";
        printInOrder(n->right);
}

void AVLtree::printPreOrder(AVLtree::Node *n) 
{
    if (n) {
        cout<<get<0>(n->value)<<"."<<get<1>(n->value)<<" ";        
        printPreOrder(n->left);
        printPreOrder(n->right);
    }
}

AVLtree::Node* AVLtree::getNodeFor(int integer, int decimal, Node* n)
{
    if(n){
        if(get<0>(n->value)==integer || get<1>(n->value)==decimal)
            return n;
        else{
            Node *p = getNodeFor(integer, decimal, n->left);
            if(p) return p;
            else return getNodeFor(integer, decimal, n->right);
        }
    }
    return NULL;
}

void AVLtree::rotate(Node *n) 
{
    if(!n) return;
    if(!n->parent) return;
    if(!n->parent->parent) return;
    if ((n == n->parent->right) && (n->parent->left == NULL)
        && (n->parent == n->parent->parent->right) 
        && (n->parent->parent->left == NULL)) //rotateL case
        rotateL(n);
    if ((n == n->parent->left) && (n->parent->right == NULL)
        && (n->parent == n->parent->parent->left)
        && (n->parent->parent->right == NULL)) //rotateR case
        rotateR(n);
    if ((n == n->parent->right) && (n->parent->left == NULL)
        && (n->parent == n->parent->parent->left)
        && (n->parent->parent->right == NULL)) //rotateLR
        rotateLR(n);
    if ((n == n->parent->left) && (n->parent->right == NULL)
        && (n->parent == n->parent->parent->right)
        && (n->parent->parent->left == NULL)) //rotateRL
        rotateRL(n);
}

void AVLtree::rotateL(Node *c) 
{
    Node* b = c->parent;
    Node* a = b->parent;
    b->parent = a->parent;
    a->parent = b;
    a->right = NULL;
    b->left = a;
    // a->depth += 1;
    // b->depth -= 1;
    // c->depth -= 1;
}

void AVLtree::rotateR(Node *a) 
{
    Node* b = a->parent;
    Node* c = b->parent;
    b->parent = c->parent;
    c->parent = b;
    b->right = c;
    c->left = NULL;
    // c->depth++;
    // b->depth--;
    // a->depth--;
}

void AVLtree::rotateLR(Node *b) 
{
    Node* a = b->parent;
    Node* c = a->parent;
    c->left = b;
    b->left = a;
    b->parent = c;
    a->parent = b;
    a->right = NULL;
    // b->depth--;
    // a->depth++;
    rotateR(a);
}

void AVLtree::rotateRL(Node *b) 
{
    Node* c = b->parent;
    Node* a = c->parent;
    a->right = b;
    b->parent = a;
    b->right = c;
    c->parent = b;
    c->left = NULL;
    // b->depth++;
    // c->depth--;
    rotateL(c);
}

int AVLtree::getHeight(Node *n) 
{
    if (!n) return 0;
    else{
        int heightL = getHeight(n->left);
        int heightR = getHeight(n->right);
        if (heightL > heightR)
            return heightL + 1;
        else return heightR + 1;
    }
}

int AVLtree::getLHeight(Node *n) 
{
    return getHeight(n->left);
}

int AVLtree::getRHeight(Node *n) 
{
    return getHeight(n->right);
}

void AVLtree::dNHelper(Node* root, int level, int& maxLevel, Node* deepest) 
{
    if(root != NULL){
        dNHelper(root->left, ++level, maxLevel, deepest);
        if(level>maxLevel)
        {
            deepest = root;
            maxLevel = level;
        }
        dNHelper(root->right, level, maxLevel, deepest);
    }
}

AVLtree::Node* AVLtree::deepestNode(Node *root) 
{
    Node* deepest = root;
    int maxLevel = -1;
    dNHelper(root, 0, maxLevel, deepest);
    return deepest;
}



